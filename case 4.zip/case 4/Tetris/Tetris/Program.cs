﻿using System;
using System.Threading;

namespace Tetris
{
    internal class Program
    {
        // Шаблоны фигур (1 = блок)
        static readonly int[][,] Shapes = new int[][,]
        {
            new int[,] { { 1, 1, 1, 1 } },              // I
            new int[,] { { 1, 1 }, { 1, 1 } },          // O
            new int[,] { { 1, 1, 1 }, { 0, 1, 0 } },    // T
            new int[,] { { 0, 1, 1 }, { 1, 1, 0 } },    // S
            new int[,] { { 1, 1, 0 }, { 0, 1, 1 } },    // Z
            new int[,] { { 1, 1, 1 }, { 1, 0, 0 } },    // L
            new int[,] { { 1, 1, 1 }, { 0, 0, 1 } }     // J
        };

        static readonly Random rnd = new Random();

        static void Main()
        {
            Console.CursorVisible = false;
            Console.Title = "Тетрис";

            try { Console.SetWindowSize(40, 30); } catch { }
            try { Console.SetBufferSize(40, 30); } catch { }

            while (true)
            {
                bool restart = RunGame();
                if (!restart) break;
            }

            Console.Clear();
            Console.WriteLine("Спасибо за игру!");
        }

        static bool RunGame()
        {
            Console.Clear();

            Field field = new Field(10, 20);
            Figure current = SpawnFigure();
            int score = 0;
            int dropInterval = 400;             // мс
            DateTime lastDrop = DateTime.Now;

            while (true)
            {
                // --- Ввод игрока ---
                while (Console.KeyAvailable)
                {
                    var key = Console.ReadKey(true).Key;

                    switch (key)
                    {
                        case ConsoleKey.LeftArrow:
                            if (field.CanPlace(current, -1, 0)) current.X--;
                            break;

                        case ConsoleKey.RightArrow:
                            if (field.CanPlace(current, 1, 0)) current.X++;
                            break;

                        case ConsoleKey.DownArrow:
                            if (field.CanPlace(current, 0, 1)) current.Y++;
                            lastDrop = DateTime.Now;
                            break;

                        case ConsoleKey.UpArrow:
                            {
                                var old = current.Shape;
                                current.Rotate();
                                if (!field.CanPlace(current))
                                    current.Shape = old; // откат
                                break;
                            }

                        case ConsoleKey.Spacebar:
                            while (field.CanPlace(current, 0, 1)) current.Y++;
                            lastDrop = DateTime.MinValue; // ускорить фиксацию
                            break;

                        case ConsoleKey.Escape:
                            return false;
                    }
                }

                // --- Автопадание ---
                if ((DateTime.Now - lastDrop).TotalMilliseconds >= dropInterval)
                {
                    if (field.CanPlace(current, 0, 1))
                    {
                        current.Y++;
                    }
                    else
                    {
                        // Фиксация фигуры
                        field.Lock(current);
                        score += field.ClearFullLines() * 100;

                        // Новая фигура
                        current = SpawnFigure();

                        // Проверка game over
                        if (!field.CanPlace(current))
                        {
                            field.Draw(null);
                            Console.SetCursorPosition(0, 23);
                            Console.WriteLine($"Игра окончена! Ваш счёт: {score}        ");
                            Console.WriteLine("Нажмите R для рестарта или Esc для выхода. ");

                            while (true)
                            {
                                var k = Console.ReadKey(true).Key;
                                if (k == ConsoleKey.R) return true;
                                if (k == ConsoleKey.Escape) return false;
                            }
                        }
                    }
                    lastDrop = DateTime.Now;
                }

                // --- Отрисовка ---
                field.Draw(current);
                Console.SetCursorPosition(0, 23);
                Console.WriteLine($"Счёт: {score}        ");

                Thread.Sleep(30);
            }
        }

        static Figure SpawnFigure()
        {
            int idx = rnd.Next(Shapes.Length);
            return new Figure(Shapes[idx]);
        }
    }
}