using System;

namespace Tetris
{
    /// <summary>
    /// Игровое поле 10×20. Каждая ячейка:
    /// 0 — пусто, 1 — занято уложенным блоком.
    /// </summary>
    public class Field
    {
        public int Width  { get; }
        public int Height { get; }
        public int[,] Grid { get; }

        public Field(int width = 10, int height = 20)
        {
            Width  = width;
            Height = height;
            Grid   = new int[height, width];
        }

        /// <summary>Можно ли разместить фигуру со смещением (dx, dy)?</summary>
        public bool CanPlace(Figure fig, int dx = 0, int dy = 0)
        {
            int rows = fig.Shape.GetLength(0);
            int cols = fig.Shape.GetLength(1);

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (fig.Shape[i, j] == 0) continue;

                    int x = fig.X + j + dx;
                    int y = fig.Y + i + dy;

                    if (x < 0 || x >= Width)  return false;
                    if (y >= Height)          return false;
                    if (y >= 0 && Grid[y, x] == 1) return false;
                }
            }
            return true;
        }

        /// <summary>Зафиксировать фигуру на поле.</summary>
        public void Lock(Figure fig)
        {
            int rows = fig.Shape.GetLength(0);
            int cols = fig.Shape.GetLength(1);

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    if (fig.Shape[i, j] == 1)
                    {
                        int x = fig.X + j;
                        int y = fig.Y + i;
                        if (y >= 0 && y < Height && x >= 0 && x < Width)
                            Grid[y, x] = 1;
                    }
        }

        /// <summary>Удаляет заполненные линии, возвращает их количество.</summary>
        public int ClearFullLines()
        {
            int cleared = 0;

            for (int i = Height - 1; i >= 0; i--)
            {
                bool full = true;
                for (int j = 0; j < Width; j++)
                    if (Grid[i, j] == 0) { full = false; break; }

                if (full)
                {
                    cleared++;

                    // Сдвигаем всё выше на одну строку вниз
                    for (int k = i; k > 0; k--)
                        for (int j = 0; j < Width; j++)
                            Grid[k, j] = Grid[k - 1, j];

                    // Верхняя строка — пустая
                    for (int j = 0; j < Width; j++)
                        Grid[0, j] = 0;

                    i++; // проверить эту же позицию заново
                }
            }
            return cleared;
        }

        /// <summary>Отрисовка поля + текущей фигуры (если она не null).</summary>
        public void Draw(Figure current)
        {
            Console.SetCursorPosition(0, 0);

            // Копия поля, чтобы «наложить» фигуру
            int[,] view = (int[,])Grid.Clone();

            if (current != null)
            {
                int rows = current.Shape.GetLength(0);
                int cols = current.Shape.GetLength(1);

                for (int i = 0; i < rows; i++)
                    for (int j = 0; j < cols; j++)
                        if (current.Shape[i, j] == 1)
                        {
                            int x = current.X + j;
                            int y = current.Y + i;
                            if (y >= 0 && y < Height && x >= 0 && x < Width)
                                view[y, x] = 2; // 2 = активная фигура
                        }
            }

            // Верхняя граница
            Console.WriteLine("+" + new string('-', Width * 2) + "+");

            for (int i = 0; i < Height; i++)
            {
                Console.Write("|");
                for (int j = 0; j < Width; j++)
                {
                    switch (view[i, j])
                    {
                        case 0: Console.Write(" ."); break;   // пусто
                        case 1: Console.Write("[]"); break;   // уложено
                        case 2: Console.Write("[]"); break;   // фигура
                    }
                }
                Console.WriteLine("|");
            }

            // Нижняя граница
            Console.WriteLine("+" + new string('-', Width * 2) + "+");
        }
    }
}