namespace Tetris
{
    /// <summary>
    /// Фигура тетриса. Хранится как матрица битов:
    /// 1 — блок фигуры, 0 — пусто.
    /// </summary>
    public class Figure
    {
        public int[,] Shape { get; set; }
        public int X { get; set; }
        public int Y { get; set; }

        public Figure(int[,] shape)
        {
            // Копия, чтобы не портить шаблон из Program.cs
            Shape = (int[,])shape.Clone();
            X = 3;
            Y = 0;
        }

        /// <summary>Поворот фигуры на 90° по часовой стрелке.</summary>
        public void Rotate()
        {
            int rows = Shape.GetLength(0);
            int cols = Shape.GetLength(1);
            int[,] rotated = new int[cols, rows];

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    rotated[j, rows - 1 - i] = Shape[i, j];

            Shape = rotated;
        }
    }
}